
import React, { useEffect } from "react";
import { Link } from "react-router-dom";

const Index = () => {
  useEffect(() => {
    // Sticky header on scroll
    const handleScroll = () => {
      const header = document.querySelector('header');
      if (header) {
        if (window.scrollY > 50) {
          header.classList.add('sticky-header');
        } else {
          header.classList.remove('sticky-header');
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  // Mobile menu toggle
  const toggleMobileMenu = () => {
    const mobileMenu = document.getElementById('mobile-menu');
    if (mobileMenu) {
      if (mobileMenu.classList.contains('hidden')) {
        mobileMenu.classList.remove('hidden');
        mobileMenu.classList.add('flex');
      } else {
        mobileMenu.classList.add('hidden');
        mobileMenu.classList.remove('flex');
      }
    }
  };

  // Smooth scrolling
  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({
      behavior: 'smooth'
    });
    
    // Close mobile menu if open
    const mobileMenu = document.getElementById('mobile-menu');
    if (mobileMenu) {
      mobileMenu.classList.add('hidden');
      mobileMenu.classList.remove('flex');
    }
  };

  return (
    <div className="font-sans text-gray-800">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 transition-all duration-300 sticky-header">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center">
            <h1 className="text-3xl font-bold logo">SPORTSMEN'S</h1>
            <span className="ml-2 text-gray-600 font-semibold">BAR & GRILL</span>
          </div>
          <nav className="hidden md:block">
            <ul className="flex space-x-8">
              <li><a href="#home" onClick={() => scrollToSection('home')} className="nav-link text-gray-800 hover:text-amber-500 font-medium">Home</a></li>
              <li><a href="#about" onClick={() => scrollToSection('about')} className="nav-link text-gray-800 hover:text-amber-500 font-medium">About</a></li>
              <li><a href="#menu" onClick={() => scrollToSection('menu')} className="nav-link text-gray-800 hover:text-amber-500 font-medium">Menu</a></li>
              <li><a href="#hours" onClick={() => scrollToSection('hours')} className="nav-link text-gray-800 hover:text-amber-500 font-medium">Hours</a></li>
              <li><a href="#contact" onClick={() => scrollToSection('contact')} className="nav-link text-gray-800 hover:text-amber-500 font-medium">Contact</a></li>
            </ul>
          </nav>
          <div className="md:hidden">
            <button className="text-gray-800 focus:outline-none" onClick={toggleMobileMenu}>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
          <div className="hidden md:block">
            <a href="tel:+17017346465" className="bg-amber-500 hover:bg-amber-600 text-white py-2 px-4 rounded-lg font-medium transition duration-300 flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
              </svg> Call Now
            </a>
          </div>
        </div>
      </header>

      {/* Mobile Navigation (Hidden by default) */}
      <div className="fixed inset-0 bg-gray-900 bg-opacity-95 z-50 hidden flex-col justify-center items-center" id="mobile-menu">
        <button className="absolute top-6 right-6 text-white focus:outline-none" onClick={toggleMobileMenu}>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
        <ul className="flex flex-col space-y-6 text-center">
          <li><a href="#home" onClick={() => scrollToSection('home')} className="text-white text-2xl hover:text-amber-500 font-medium">Home</a></li>
          <li><a href="#about" onClick={() => scrollToSection('about')} className="text-white text-2xl hover:text-amber-500 font-medium">About</a></li>
          <li><a href="#menu" onClick={() => scrollToSection('menu')} className="text-white text-2xl hover:text-amber-500 font-medium">Menu</a></li>
          <li><a href="#hours" onClick={() => scrollToSection('hours')} className="text-white text-2xl hover:text-amber-500 font-medium">Hours</a></li>
          <li><a href="#contact" onClick={() => scrollToSection('contact')} className="text-white text-2xl hover:text-amber-500 font-medium">Contact</a></li>
        </ul>
        <a href="tel:+17017346465" className="mt-10 bg-amber-500 hover:bg-amber-600 text-white py-3 px-6 rounded-lg font-medium transition duration-300 flex items-center text-xl">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
          </svg> Call Now: (701) 734-6465
        </a>
      </div>

      <main>
        {/* Hero Section */}
        <section id="home" className="hero flex items-center justify-center pt-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-4">SPORTSMEN'S BAR & GRILL</h1>
            <p className="text-xl md:text-2xl text-gray-200 mb-8">Wilton's Favorite Sports Bar & Grill Since 1995</p>
            <div className="flex flex-col md:flex-row justify-center gap-4">
              <a href="#menu" onClick={() => scrollToSection('menu')} className="bg-amber-500 hover:bg-amber-600 text-white py-3 px-8 rounded-lg font-medium text-lg transition duration-300">
                View Our Menu
              </a>
              <a href="#contact" onClick={() => scrollToSection('contact')} className="bg-transparent border-2 border-white hover:bg-white hover:text-gray-900 text-white py-3 px-8 rounded-lg font-medium text-lg transition duration-300">
                Find Us
              </a>
            </div>
          </div>
        </section>

        {/* About Section */}
        <section id="about" className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold mb-4">ABOUT US</h2>
              <div className="w-20 h-1 bg-amber-500 mx-auto"></div>
            </div>
            <div className="flex flex-col lg:flex-row items-center">
              <div className="lg:w-1/2 mb-8 lg:mb-0 lg:pr-12">
                <h3 className="text-2xl font-semibold mb-4">Welcome to Sportsmen's Bar & Grill</h3>
                <p className="text-gray-700 mb-4">Sportsmen's Bar & Grill has been serving the Wilton community since 1995. We're a casual bar and grill known for our delicious steaks, burgers, and friendly atmosphere. Whether you're looking to catch the game, enjoy a meal with friends, or just relax with a cold drink, we've got you covered.</p>
                <p className="text-gray-700 mb-6">Our casual and welcoming environment makes us the perfect spot for lunch, dinner, or late-night drinks. With multiple TVs throughout the establishment, you'll never miss a moment of your favorite sporting events.</p>
                <div className="flex items-center mb-2">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-amber-500 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <span className="text-gray-800">Delicious comfort food</span>
                </div>
                <div className="flex items-center mb-2">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-amber-500 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <span className="text-gray-800">Sports viewing on multiple screens</span>
                </div>
                <div className="flex items-center mb-2">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-amber-500 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <span className="text-gray-800">Daily food and drink specials</span>
                </div>
                <div className="flex items-center mb-6">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-amber-500 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                  <span className="text-gray-800">Friendly and attentive service</span>
                </div>
                <a href="#contact" onClick={() => scrollToSection('contact')} className="inline-block bg-amber-500 hover:bg-amber-600 text-white py-3 px-6 rounded-lg font-medium transition duration-300">
                  Visit Us Today
                </a>
              </div>
              <div className="lg:w-1/2">
                <div className="grid grid-cols-2 gap-4">
                  <img src="https://img.restaurantguru.com/cbde-Sportsman-Wilton-photo.jpg" alt="Sportsmen's Bar Interior" className="rounded-lg shadow-lg w-full h-64 object-cover" />
                  <img src="https://img.restaurantguru.com/cf8c-Sportsman-Wilton-interior.jpg" alt="Sportsmen's Bar and Grill" className="rounded-lg shadow-lg w-full h-64 object-cover" />
                  <img src="https://s3-media0.fl.yelpcdn.com/bphoto/1bmVYAkqIk3rdB6Cw3LXsg/348s.jpg" alt="Sportsmen's Bar Entrance" className="rounded-lg shadow-lg w-full h-64 object-cover" />
                  <img src="https://img.restaurantguru.com/r8df-Sportsman-interior-2021-08.jpg" alt="Sportsmen's Bar Interior" className="rounded-lg shadow-lg w-full h-64 object-cover" />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-gray-900 text-white py-12">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row justify-between">
              <div className="mb-8 md:mb-0">
                <h3 className="text-2xl font-bold mb-4 logo">SPORTSMEN'S</h3>
                <p className="text-gray-400 mb-4">Bar & Grill</p>
                <p className="text-gray-400">21 Dakota Ave, Wilton, ND 58579</p>
                <p className="text-gray-400">Phone: +1 701-734-6465</p>
              </div>
              <div className="mb-8 md:mb-0">
                <h4 className="text-xl font-semibold mb-4">Quick Links</h4>
                <ul className="space-y-2">
                  <li><a href="#home" onClick={() => scrollToSection('home')} className="text-gray-400 hover:text-amber-500 transition duration-300">Home</a></li>
                  <li><a href="#about" onClick={() => scrollToSection('about')} className="text-gray-400 hover:text-amber-500 transition duration-300">About</a></li>
                  <li><a href="#menu" onClick={() => scrollToSection('menu')} className="text-gray-400 hover:text-amber-500 transition duration-300">Menu</a></li>
                  <li><a href="#hours" onClick={() => scrollToSection('hours')} className="text-gray-400 hover:text-amber-500 transition duration-300">Hours</a></li>
                  <li><a href="#contact" onClick={() => scrollToSection('contact')} className="text-gray-400 hover:text-amber-500 transition duration-300">Contact</a></li>
                </ul>
              </div>
              <div>
                <h4 className="text-xl font-semibold mb-4">Business Hours</h4>
                <p className="text-gray-400 mb-2">Monday - Saturday: 10:00 AM - 1:00 AM</p>
                <p className="text-gray-400 mb-4">Sunday: Closed</p>
                <p className="text-gray-400 mb-4">Kitchen closes one hour before bar closing time.</p>
                <div className="flex space-x-4">
                  <a href="https://www.facebook.com/sportsmensbarandgrill" target="_blank" rel="noopener noreferrer" className="bg-gray-800 hover:bg-amber-500 w-10 h-10 rounded-full flex items-center justify-center transition duration-300">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M9 8h-3v4h3v12h5v-12h3.642l.358-4h-4v-1.667c0-.955.192-1.333 1.115-1.333h2.885v-5h-3.808c-3.596 0-5.192 1.583-5.192 4.615v3.385z" />
                    </svg>
                  </a>
                  <a href="#" className="bg-gray-800 hover:bg-amber-500 w-10 h-10 rounded-full flex items-center justify-center transition duration-300">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                    </svg>
                  </a>
                </div>
              </div>
            </div>
            <div className="border-t border-gray-800 mt-10 pt-8 text-center">
              <p className="text-gray-500">© 2025 Sportsmen's Bar and Grill. All Rights Reserved.</p>
            </div>
          </div>
        </footer>
      </main>

      <style jsx>{`
        body {
          font-family: 'Montserrat', sans-serif;
          color: #333;
          background-color: #f9f9f9;
        }
        h1, h2, h3, h4, h5 {
          font-family: 'Oswald', sans-serif;
        }
        .hero {
          background-image: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('https://img.restaurantguru.com/r125-Sportsman-exterior-2021-08.jpg');
          background-size: cover;
          background-position: center;
          height: 90vh;
        }
        .menu-card {
          transition: all 0.3s ease;
        }
        .menu-card:hover {
          transform: translateY(-5px);
          box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        .hours-container {
          background-image: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('https://img.restaurantguru.com/cf8c-Sportsman-Wilton-interior.jpg');
          background-size: cover;
          background-position: center;
        }
        .nav-link {
          position: relative;
        }
        .nav-link::after {
          content: '';
          position: absolute;
          width: 0;
          height: 2px;
          bottom: 0;
          left: 0;
          background-color: #f59e0b;
          transition: width 0.3s;
        }
        .nav-link:hover::after {
          width: 100%;
        }
        .contact-info {
          background-image: linear-gradient(rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0.8)), url('https://img.restaurantguru.com/r8df-Sportsman-interior-2021-08.jpg');
          background-size: cover;
          background-position: center;
        }
        .gallery-image {
          transition: transform 0.3s ease;
        }
        .gallery-image:hover {
          transform: scale(1.05);
        }
        .logo {
          font-family: 'Oswald', sans-serif;
          background: linear-gradient(90deg, #d4af37 0%, #f59e0b 100%);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          text-shadow: 1px 1px 1px rgba(0,0,0,0.1);
        }
        .sticky-header {
          background-color: rgba(255, 255, 255, 0.95);
          box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        @media (max-width: 768px) {
          .hero {
            height: 60vh;
          }
        }
      `}</style>
    </div>
  );
};

export default Index;
